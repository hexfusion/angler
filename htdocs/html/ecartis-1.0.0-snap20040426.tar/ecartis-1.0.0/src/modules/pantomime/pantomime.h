#ifndef _PANTOMIME_H
#define _PANTOMIME_H
#include <stdio.h>
#include "lpm.h"

extern struct LPMAPI *LMAPI;

extern MIME_HANDLER(mimehandle_html);
extern MIME_HANDLER(mimehandle_pantomime_binary);

#endif /* _TOOLBOX_H */
