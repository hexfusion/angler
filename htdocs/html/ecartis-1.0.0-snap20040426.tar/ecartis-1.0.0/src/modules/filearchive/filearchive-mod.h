#ifndef _FILEARCHIVE_MOD_H
#define _FILEARCHIVE_MOD_H

#define FILEARCHIVE_VERSION "1.0"

extern int cmd_file_index(CMD_PARAMS);
extern int cmd_get_file(CMD_PARAMS);

#endif /* _FILEARCHIVE_MOD_H */
