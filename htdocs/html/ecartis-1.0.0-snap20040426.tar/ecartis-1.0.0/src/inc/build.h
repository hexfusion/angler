#ifndef _BUILD_H
#define _BUILD_H

#define CUR_BUILD_VERSION 7

#endif /* _BUILD_H */
