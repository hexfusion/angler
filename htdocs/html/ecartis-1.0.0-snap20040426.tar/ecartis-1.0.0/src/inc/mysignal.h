#ifndef __MYSIGNAL_H
#define __MYSIGNAL_H

extern void init_signals(void);

#endif // __MYSIGNAL_H
