#ifdef NEED_SNPRINTF
int my_snprintf (char *str, size_t count, const char *fmt, ...);
int my_vsnprintf (char *str, size_t count, const char *fmt, va_list arg);
#endif
