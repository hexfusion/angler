#ifndef _FORMS_H
#define _FORMS_H

extern int task_heading(const char *toaddy);
extern void task_ending(void);
extern int error_heading(void);
extern void error_ending(void);

#endif /* _FORMS_H */
