#ifndef _INIT_H
#define _INIT_H

extern void init_commands();
extern void init_flags();
extern void init_files();

#endif /* _INIT_H */
