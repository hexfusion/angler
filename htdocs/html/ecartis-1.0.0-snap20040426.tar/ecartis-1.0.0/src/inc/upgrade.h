#ifndef _UPGRADE_H
#define _UPGRADE_H

extern int upgrade_listserver(int prev, int cur);
extern int upgrade_list(int prev, int cur); 

#endif /* _UPGRADE_H */
