#ifndef _RFC2047_H
#define _RFC2047_H

void rfc2047_decode (const char *orig, char *dest, int maxlen);

#endif /* _RFC2047_H */
