#ifndef _LISCRIPT_H

extern int liscript_parse_line(const char *, char *, int);
extern int liscript_parse_file(const char *, const char *);

#endif
