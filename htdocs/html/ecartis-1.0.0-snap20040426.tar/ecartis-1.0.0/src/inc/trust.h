#ifndef _TRUST_H
#define _TRUST_H

extern int is_trusted(const char *list);
extern void init_restricted_vars();

#endif
