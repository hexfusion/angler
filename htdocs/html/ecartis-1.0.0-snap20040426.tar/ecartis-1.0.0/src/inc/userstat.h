#ifndef _USERSTAT_H
#define _USERSTAT_H

extern int userstat_get_stat(const char *, const char *, const char *, char *, int);
extern int userstat_set_stat(const char *, const char *, const char *, const char *);

#endif
