#ifndef __UNHTML_H
#define __UNHTML_H

extern int unhtml_file(const char *file1, const char *file2);

#endif
