#ifndef _INTERNAL_H
#define _INTERNAL_H

extern void init_internal(void);
extern int upgrade_listserver(int prev, int cur);
extern int upgrade_list(int prev, int cur);

#endif /* _INTERNAL_H */
