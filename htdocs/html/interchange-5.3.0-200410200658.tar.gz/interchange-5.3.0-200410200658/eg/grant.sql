GRANT ALL
ON mwforum.*
TO aws@localhost
IDENTIFIED BY 'keiko';
